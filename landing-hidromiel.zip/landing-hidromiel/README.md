# Landing — Curso Premium de Elaboración de Hidromiel

Landing page estática (HTML + CSS + JS en un solo archivo) con temporizador de oferta,
datos de pago y diseño dorado inspirado en el póster del curso. Lista para publicar en
**GitHub Pages**.

## Archivos

| Archivo | Descripción |
| --- | --- |
| `index.html` | La página completa (única página, no requiere servidor) |
| `assets/` | Imágenes recortadas del póster (copa, eBooks, calculadora, certificado) |
| `README.md` | Esta guía |

## Publicar en GitHub Pages (paso a paso)

1. Inicia sesión en [github.com](https://github.com) y crea un repositorio nuevo
   (botón **`+`** arriba a la derecha → **New repository**).
2. Nómbralo, por ejemplo, `curso-hidromiel` y márcalo como **público**.
3. En la página del repositorio, entra a **"uploading an existing file"**
   (o botón **Add file → Upload files**) y arrastra `index.html` y la carpeta `assets/`.
4. Pulsa **Commit changes**.
5. Ve a **Settings → Pages** (menú lateral izquierdo).
6. En **Branch** elige `main` y la carpeta `/ (root)`, y pulsa **Save**.
7. Espera 1–2 minutos y tu página estará disponible en:
   `https://TU_USUARIO.github.io/curso-hidromiel/`

> GitHub Pages sirve el archivo `index.html` automáticamente desde la raíz del repositorio.

## Personalización rápida

Todos los cambios se hacen editando `index.html` con cualquier editor de texto:

- **Número de WhatsApp**: busca `52XXXXXXXXXX` y reemplázalo por tu número real
  (formato internacional, sin `+` ni espacios; ejemplo México: `5215512345678`).
- **Hora límite del temporizador**: busca `(22, 30, 0)` en el bloque del script
  y cambia la hora de cierre de la oferta (22:30 = 10:30 PM).
- **Precio**: busca `999`.
- **Datos bancarios**: busca las secciones `pay-card`.

## Temporizador

La cuenta atrás llega hasta las **10:30 PM del día actual**; si la hora pasa,
se reinicia automáticamente hacia las 10:30 PM del día siguiente, de modo que
la oferta siempre muestra un plazo vigente.
